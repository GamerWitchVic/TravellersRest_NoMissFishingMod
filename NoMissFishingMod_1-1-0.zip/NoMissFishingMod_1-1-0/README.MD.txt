# TravellersRest_NoMissFishingMod
A Travellers Rest mod that makes fishing much easier! 
- Once you've entered the fishing minigame, you'll never lose

## Backup your save before adding mods:
Either use the "duplicate" feature on the load screen or make a copy of GameSaves in  `%userprofile%\appdata\locallow\Louqou\TravellersRest\`

## How to install mods:
- Install Bepinex﻿ (Stable version 5.4 for Windows 64)
- Start the game, quit the game after it finishes loading
- This will create a Bepinex config file and a plugins folder that you can put additional mods in
- (optional) Enable the Bepinex Console (see the detailed guide or the Bepinex documentation for steps)
- Copy the mod .dll to the plugins directory.

## NOTE
If you have issues running the plugin, move the files in .additional_files to BepInEx/core. 

Is this mod save to add/remove mid play-through?
Yes.
